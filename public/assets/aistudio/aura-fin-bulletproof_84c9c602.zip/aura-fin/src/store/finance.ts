import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type TransactionType = 'income' | 'expense' | 'transfer'
export type CategoryType =
  | 'salary'
  | 'freelance'
  | 'food'
  | 'transport'
  | 'utilities'
  | 'health'
  | 'education'
  | 'entertainment'
  | 'other'

export interface Transaction {
  id: string
  type: TransactionType
  amount: number
  category: CategoryType
  description: string
  date: string
  dueDate?: string
  status: 'pending' | 'completed'
  recurrence?: 'daily' | 'weekly' | 'monthly' | 'yearly'
}

export interface Account {
  id: string
  name: string
  type: 'checking' | 'savings' | 'credit'
  balance: number
  currency: string
  color?: string
}

export interface FinanceStore {
  transactions: Transaction[]
  accounts: Account[]

  addTransaction: (transaction: Omit<Transaction, 'id'>) => void
  removeTransaction: (id: string) => void
  updateTransaction: (id: string, updates: Partial<Transaction>) => void

  addAccount: (account: Omit<Account, 'id'>) => void
  removeAccount: (id: string) => void
  updateAccount: (id: string, updates: Partial<Account>) => void

  getTotalIncome: (startDate?: string, endDate?: string) => number
  getTotalExpense: (startDate?: string, endDate?: string) => number
  getBalance: () => number
  getTransactionsByCategory: (category: CategoryType) => Transaction[]
}

const initialAccounts: Account[] = [
  {
    id: '1',
    name: 'Conta Principal',
    type: 'checking',
    balance: 0,
    currency: 'BRL',
    color: '#7893ff',
  },
]

export const useFinanceStore = create<FinanceStore>()(
  persist(
    (set, get) => ({
      transactions: [],
      accounts: initialAccounts,

      addTransaction: (transaction) =>
        set((state) => ({
          transactions: [
            ...state.transactions,
            { ...transaction, id: Date.now().toString() },
          ],
        })),

      removeTransaction: (id) =>
        set((state) => ({
          transactions: state.transactions.filter((t) => t.id !== id),
        })),

      updateTransaction: (id, updates) =>
        set((state) => ({
          transactions: state.transactions.map((t) =>
            t.id === id ? { ...t, ...updates } : t
          ),
        })),

      addAccount: (account) =>
        set((state) => ({
          accounts: [...state.accounts, { ...account, id: Date.now().toString() }],
        })),

      removeAccount: (id) =>
        set((state) => ({
          accounts: state.accounts.filter((a) => a.id !== id),
        })),

      updateAccount: (id, updates) =>
        set((state) => ({
          accounts: state.accounts.map((a) =>
            a.id === id ? { ...a, ...updates } : a
          ),
        })),

      getTotalIncome: (startDate, endDate) => {
        const { transactions } = get()
        return transactions
          .filter((t) => {
            if (t.type !== 'income') return false
            if (startDate && t.date < startDate) return false
            if (endDate && t.date > endDate) return false
            return true
          })
          .reduce((sum, t) => sum + t.amount, 0)
      },

      getTotalExpense: (startDate, endDate) => {
        const { transactions } = get()
        return transactions
          .filter((t) => {
            if (t.type !== 'expense') return false
            if (startDate && t.date < startDate) return false
            if (endDate && t.date > endDate) return false
            return true
          })
          .reduce((sum, t) => sum + t.amount, 0)
      },

      getBalance: () => {
        const { accounts } = get()
        return accounts.reduce((sum, a) => sum + a.balance, 0)
      },

      getTransactionsByCategory: (category) => {
        const { transactions } = get()
        return transactions.filter((t) => t.category === category)
      },
    }),
    {
      name: 'aura-fin-finance',
      version: 1,
    }
  )
)

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface PayrollData {
  id: string
  month: string
  baseSalary: number
  grossSalary: number
  inss: number
  irrf: number
  netSalary: number
  discounts: number
  bonuses: number
  company: string
  role: string
}

export interface PayrollSimulation {
  vacationDays: number
  thirteenthSalary: number
  terminationDate?: string
  severanceFund: number
  totalTermination: number
}

export interface PayrollStore {
  payrolls: PayrollData[]
  creaFee: number
  registrationNumber: string

  addPayroll: (payroll: Omit<PayrollData, 'id'>) => void
  updatePayroll: (id: string, updates: Partial<PayrollData>) => void
  removePayroll: (id: string) => void

  setCREAFee: (fee: number) => void
  setRegistrationNumber: (number: string) => void

  simulateTermination: (baseSalary: number, monthsWorked: number) => PayrollSimulation
  calculateVacationBonus: (baseSalary: number, days: number) => number
  calculateTaxes: (grossSalary: number) => { inss: number; irrf: number }
  getAverageNetSalary: () => number
}

export const usePayrollStore = create<PayrollStore>()(
  persist(
    (set, get) => ({
      payrolls: [],
      creaFee: 0,
      registrationNumber: '',

      addPayroll: (payroll) =>
        set((state) => ({
          payrolls: [...state.payrolls, { ...payroll, id: Date.now().toString() }],
        })),

      updatePayroll: (id, updates) =>
        set((state) => ({
          payrolls: state.payrolls.map((p) =>
            p.id === id ? { ...p, ...updates } : p
          ),
        })),

      removePayroll: (id) =>
        set((state) => ({
          payrolls: state.payrolls.filter((p) => p.id !== id),
        })),

      setCREAFee: (fee) => set({ creaFee: fee }),
      setRegistrationNumber: (number) => set({ registrationNumber: number }),

      simulateTermination: (baseSalary, monthsWorked) => {
        const vacationDays = Math.floor((monthsWorked / 12) * 30)
        const vacationValue = baseSalary * (vacationDays / 30)
        const thirteenthSalary =
          baseSalary * Math.floor(monthsWorked / 12) +
          (baseSalary / 12) * (monthsWorked % 12)
        const severanceFund = baseSalary * (monthsWorked / 12) * 0.08

        return {
          vacationDays,
          thirteenthSalary,
          severanceFund,
          totalTermination:
            baseSalary +
            vacationValue +
            thirteenthSalary +
            severanceFund,
        }
      },

      calculateVacationBonus: (baseSalary, days) => {
        return baseSalary * (days / 30) * 1.33
      },

      calculateTaxes: (grossSalary) => {
        // Simplified INSS calculation (2024 brackets)
        let inss = 0
        if (grossSalary <= 1412.0) inss = grossSalary * 0.075
        else if (grossSalary <= 2666.68) inss = grossSalary * 0.09
        else if (grossSalary <= 4000.03) inss = grossSalary * 0.12
        else inss = grossSalary * 0.14

        // Simplified IRRF calculation
        let irrf = 0
        if (grossSalary > 2824.0) {
          irrf = (grossSalary - 2824.0) * 0.075
          if (grossSalary > 3751.05)
            irrf = (3751.05 - 2824.0) * 0.075 + (grossSalary - 3751.05) * 0.15
          if (grossSalary > 4664.68)
            irrf =
              (3751.05 - 2824.0) * 0.075 +
              (4664.68 - 3751.05) * 0.15 +
              (grossSalary - 4664.68) * 0.225
          if (grossSalary > 11236.06)
            irrf =
              (3751.05 - 2824.0) * 0.075 +
              (4664.68 - 3751.05) * 0.15 +
              (11236.06 - 4664.68) * 0.225 +
              (grossSalary - 11236.06) * 0.275
        }

        return { inss, irrf }
      },

      getAverageNetSalary: () => {
        const { payrolls } = get()
        if (payrolls.length === 0) return 0
        const totalNet = payrolls.reduce((sum, p) => sum + p.netSalary, 0)
        return totalNet / payrolls.length
      },
    }),
    {
      name: 'aura-fin-payroll',
      version: 1,
    }
  )
)

import React, { useEffect, useState } from 'react'
import { Download, X } from 'lucide-react'

declare global {
  interface BeforeInstallPromptEvent extends Event {
    prompt: () => Promise<void>
    userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>
  }
}

export const PWAInstaller: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [showPrompt, setShowPrompt] = useState(false)
  const [isInstalled, setIsInstalled] = useState(false)

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e as BeforeInstallPromptEvent)
      setShowPrompt(true)
    }

    window.addEventListener('beforeinstallprompt', handler)

    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true)
    }

    return () => window.removeEventListener('beforeinstallprompt', handler)
  }, [])

  const handleInstall = async () => {
    if (!deferredPrompt) return

    deferredPrompt.prompt()
    const { outcome } = await deferredPrompt.userChoice

    if (outcome === 'accepted') {
      setIsInstalled(true)
      setShowPrompt(false)
    }

    setDeferredPrompt(null)
  }

  // Register Service Worker
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker
        .register('/sw.js')
        .then((reg) => {
          console.log('[SW] Registrado com sucesso:', reg)

          // Check for updates periodically
          setInterval(() => {
            reg.update()
          }, 60000)
        })
        .catch((err) => {
          console.error('[SW] Erro ao registrar:', err)
        })
    }
  }, [])

  if (!showPrompt || isInstalled) return null

  return (
    <div className="fixed bottom-4 right-4 bg-white rounded-lg shadow-lg border border-gray-200 p-4 max-w-sm z-50 animate-slide-up">
      <div className="flex items-start justify-between mb-3">
        <h3 className="font-semibold text-gray-900">Instalar AuraFin</h3>
        <button
          onClick={() => setShowPrompt(false)}
          className="text-gray-500 hover:text-gray-700 p-1"
        >
          <X size={18} />
        </button>
      </div>

      <p className="text-sm text-gray-600 mb-4">
        Instale AuraFin como aplicativo para acesso offline e melhor experiência.
      </p>

      <button
        onClick={handleInstall}
        className="w-full flex items-center justify-center gap-2 bg-aurora-600 text-white px-4 py-2 rounded-lg hover:bg-aurora-700 transition font-medium"
      >
        <Download size={18} />
        Instalar
      </button>
    </div>
  )
}

import React, { useMemo } from 'react'
import { useFinanceStore } from '@/store/finance'
import { usePayrollStore } from '@/store/payroll'
import { useAccountingStore } from '@/store/accounting'
import { formatCurrency, getMonthRange } from '@/lib/utils'
import { TrendingUp, AlertCircle, Target } from 'lucide-react'

export const IntelligenceModule: React.FC = () => {
  const financeStore = useFinanceStore()
  const payrollStore = usePayrollStore()
  const accountingStore = useAccountingStore()

  const today = new Date()
  const { start, end } = getMonthRange(today)

  const monthlyIncome = financeStore.getTotalIncome(start, end)
  const monthlyExpense = financeStore.getTotalExpense(start, end)
  const balance = financeStore.getBalance()
  const averageNetSalary = payrollStore.getAverageNetSalary()

  const insights = useMemo(() => {
    const results: Array<{
      type: 'warning' | 'info' | 'success'
      title: string
      description: string
      action?: string
    }> = []

    // Análise de fluxo de caixa
    if (monthlyExpense > monthlyIncome) {
      results.push({
        type: 'warning',
        title: 'Déficit Orçamentário',
        description: `Suas despesas (${formatCurrency(monthlyExpense)}) excedem entradas (${formatCurrency(monthlyIncome)}) em ${formatCurrency(monthlyExpense - monthlyIncome)}`,
        action: 'Reduzir despesas ou aumentar receita',
      })
    }

    // Alertas de saúde financeira
    if (balance < 0) {
      results.push({
        type: 'warning',
        title: 'Saldo Negativo',
        description: `Seu saldo está em ${formatCurrency(balance)}. Procure equilibrar o fluxo o quanto antes.`,
        action: 'Revisar despesas imediatas',
      })
    } else if (balance < averageNetSalary * 0.5) {
      results.push({
        type: 'info',
        title: 'Reserva Baixa',
        description: `Sua reserva (${formatCurrency(balance)}) está abaixo de 50% do salário mensal (${formatCurrency(averageNetSalary * 0.5)})`,
        action: 'Considere aumentar a poupança',
      })
    }

    // Sugestões de alocação
    if (monthlyIncome > 0) {
      const expenseRatio = monthlyExpense / monthlyIncome
      if (expenseRatio < 0.3) {
        results.push({
          type: 'success',
          title: 'Orçamento Saudável',
          description: `Apenas ${(expenseRatio * 100).toFixed(1)}% da renda está comprometida. Ótima situação!`,
        })
      } else if (expenseRatio > 0.7) {
        results.push({
          type: 'warning',
          title: 'Orçamento Apertado',
          description: `Você está gastando ${(expenseRatio * 100).toFixed(1)}% da renda. Recomenda-se manter abaixo de 70%`,
        })
      }
    }

    // Análise de saúde geral
    const latestBalance = accountingStore.getLatestBalance()
    if (latestBalance) {
      const healthScore = accountingStore.getHealthScore()
      if (healthScore < 50) {
        results.push({
          type: 'warning',
          title: 'Saúde Financeira Crítica',
          description: `Score de saúde em ${healthScore}/100. Recomenda-se revisão urgente.`,
        })
      }
    }

    return results
  }, [monthlyIncome, monthlyExpense, balance, averageNetSalary, accountingStore])

  const recommendedAllocations = useMemo(() => {
    if (monthlyIncome === 0) return []

    return [
      {
        category: 'Necessidades Básicas',
        percentage: 50,
        current: (monthlyExpense / monthlyIncome) * 100,
        description: 'Moradia, alimentação, transporte',
      },
      {
        category: 'Desejos/Lazer',
        percentage: 30,
        current: 0,
        description: 'Entretenimento, viagens',
      },
      {
        category: 'Poupança/Investimento',
        percentage: 20,
        current: ((monthlyIncome - monthlyExpense) / monthlyIncome) * 100,
        description: 'Fundo de emergência, investimentos',
      },
    ]
  }, [monthlyIncome, monthlyExpense])

  return (
    <div className="space-y-6">
      {/* KPIs de Saúde */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-aurora-50 to-blue-50 p-4 rounded-lg border border-aurora-200">
          <p className="text-xs text-gray-600 uppercase tracking-wide">Taxa de Poupança</p>
          <p className="text-2xl font-bold text-aurora-600 mt-1">
            {monthlyIncome > 0
              ? ((((monthlyIncome - monthlyExpense) / monthlyIncome) * 100) || 0).toFixed(1)
              : 0}%
          </p>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-4 rounded-lg border border-green-200">
          <p className="text-xs text-gray-600 uppercase tracking-wide">Saldo Total</p>
          <p className="text-2xl font-bold text-green-600 mt-1">{formatCurrency(balance)}</p>
        </div>

        <div className="bg-gradient-to-br from-yellow-50 to-amber-50 p-4 rounded-lg border border-yellow-200">
          <p className="text-xs text-gray-600 uppercase tracking-wide">Razão Gasto/Renda</p>
          <p className="text-2xl font-bold text-amber-600 mt-1">
            {monthlyIncome > 0 ? ((monthlyExpense / monthlyIncome) * 100).toFixed(0) : 0}%
          </p>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-4 rounded-lg border border-purple-200">
          <p className="text-xs text-gray-600 uppercase tracking-wide">Média Salarial</p>
          <p className="text-2xl font-bold text-purple-600 mt-1">{formatCurrency(averageNetSalary)}</p>
        </div>
      </div>

      {/* Recomendações de Alocação */}
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <Target size={20} className="text-aurora-600" />
          Recomendação de Alocação de Renda
        </h3>
        <div className="space-y-4">
          {recommendedAllocations.map((alloc, idx) => (
            <div key={idx}>
              <div className="flex justify-between mb-2">
                <p className="font-medium text-sm">{alloc.category}</p>
                <p className="text-xs text-gray-600">{alloc.percentage}% recomendado</p>
              </div>
              <div className="relative h-3 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="absolute h-full bg-aurora-600 rounded-full transition-all"
                  style={{ width: `${Math.min(alloc.percentage, 100)}%` }}
                />
                {alloc.current > 0 && (
                  <div
                    className="absolute h-full border-l-2 border-green-500"
                    style={{ left: `${Math.min(alloc.current, 100)}%` }}
                    title={`Atual: ${alloc.current.toFixed(1)}%`}
                  />
                )}
              </div>
              <p className="text-xs text-gray-500 mt-1">{alloc.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Insights */}
      <div className="space-y-3">
        {insights.length === 0 ? (
          <div className="bg-green-50 p-6 rounded-lg border border-green-200 text-center">
            <p className="text-green-700 font-medium">✓ Situação financeira estável</p>
          </div>
        ) : (
          insights.map((insight, idx) => (
            <div
              key={idx}
              className={`p-4 rounded-lg border flex gap-3 ${
                insight.type === 'warning'
                  ? 'bg-red-50 border-red-200'
                  : insight.type === 'success'
                    ? 'bg-green-50 border-green-200'
                    : 'bg-blue-50 border-blue-200'
              }`}
            >
              <AlertCircle
                size={20}
                className={
                  insight.type === 'warning'
                    ? 'text-red-600 flex-shrink-0'
                    : insight.type === 'success'
                      ? 'text-green-600 flex-shrink-0'
                      : 'text-blue-600 flex-shrink-0'
                }
              />
              <div>
                <p
                  className={`font-semibold ${
                    insight.type === 'warning'
                      ? 'text-red-900'
                      : insight.type === 'success'
                        ? 'text-green-900'
                        : 'text-blue-900'
                  }`}
                >
                  {insight.title}
                </p>
                <p className="text-sm text-gray-700 mt-1">{insight.description}</p>
                {insight.action && (
                  <p className="text-xs font-medium mt-2 text-gray-600">
                    💡 Sugestão: {insight.action}
                  </p>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

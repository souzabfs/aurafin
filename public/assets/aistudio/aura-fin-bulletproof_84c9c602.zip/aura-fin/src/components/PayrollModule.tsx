import React, { useState } from 'react'
import { usePayrollStore } from '@/store/payroll'
import { formatCurrency } from '@/lib/utils'
import { Plus, Trash2 } from 'lucide-react'

export const PayrollModule: React.FC = () => {
  const {
    payrolls,
    addPayroll,
    removePayroll,
    calculateTaxes,
    simulateTermination,
    getAverageNetSalary,
    setCREAFee,
  } = usePayrollStore()

  const [formData, setFormData] = useState({
    month: new Date().toISOString().slice(0, 7),
    baseSalary: '',
    grossSalary: '',
    company: 'HNR Engenharia',
    role: 'Engenheiro Mecânico',
  })

  const [simulationData, setSimulationData] = useState({
    baseSalary: '',
    monthsWorked: '',
  })

  const [creaFeeInput, setCreaFeeInput] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.baseSalary || !formData.grossSalary) return

    const gross = parseFloat(formData.grossSalary)
    const { inss, irrf } = calculateTaxes(gross)
    const netSalary = gross - inss - irrf

    addPayroll({
      month: formData.month,
      baseSalary: parseFloat(formData.baseSalary),
      grossSalary: gross,
      inss,
      irrf,
      netSalary,
      discounts: inss + irrf,
      bonuses: 0,
      company: formData.company,
      role: formData.role,
    })

    setFormData({
      month: new Date().toISOString().slice(0, 7),
      baseSalary: '',
      grossSalary: '',
      company: 'HNR Engenharia',
      role: 'Engenheiro Mecânico',
    })
  }

  const handleSimulation = (e: React.FormEvent) => {
    e.preventDefault()
    if (!simulationData.baseSalary || !simulationData.monthsWorked) return

    const result = simulateTermination(
      parseFloat(simulationData.baseSalary),
      parseFloat(simulationData.monthsWorked)
    )

    alert(
      `Simulação de Rescisão:\n\n` +
      `Dias de férias: ${result.vacationDays}\n` +
      `Valor férias: ${formatCurrency(result.vacationDays / 30 * parseFloat(simulationData.baseSalary))}\n` +
      `13º Salário: ${formatCurrency(result.thirteenthSalary)}\n` +
      `Fundo de Garantia: ${formatCurrency(result.severanceFund)}\n` +
      `Total: ${formatCurrency(result.totalTermination)}`
    )
  }

  const handleCREAFee = () => {
    if (creaFeeInput) {
      setCREAFee(parseFloat(creaFeeInput))
      setCreaFeeInput('')
    }
  }

  const averageSalary = getAverageNetSalary()

  return (
    <div className="space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <p className="text-sm text-gray-600">Média Salarial Líquida</p>
          <p className="text-2xl font-bold text-blue-600">{formatCurrency(averageSalary)}</p>
        </div>
        <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
          <p className="text-sm text-gray-600">Anuidade CREA</p>
          <p className="text-2xl font-bold text-purple-600">{formatCurrency(payrolls[0]?.id ? 0 : 0)}</p>
        </div>
      </div>

      {/* Seção Holerite */}
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <h3 className="font-semibold mb-4">Registrar Holerite</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input
              type="month"
              value={formData.month}
              onChange={(e) => setFormData({ ...formData, month: e.target.value })}
              className="px-3 py-2 border border-gray-300 rounded-lg"
            />
            <input
              type="number"
              step="0.01"
              placeholder="Salário Base"
              value={formData.baseSalary}
              onChange={(e) => setFormData({ ...formData, baseSalary: e.target.value })}
              className="px-3 py-2 border border-gray-300 rounded-lg"
            />
          </div>

          <input
            type="number"
            step="0.01"
            placeholder="Salário Bruto"
            value={formData.grossSalary}
            onChange={(e) => setFormData({ ...formData, grossSalary: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg"
          />

          <input
            type="text"
            placeholder="Empresa"
            value={formData.company}
            onChange={(e) => setFormData({ ...formData, company: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg"
          />

          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 bg-aurora-600 text-white px-4 py-2 rounded-lg hover:bg-aurora-700 transition"
          >
            <Plus size={20} /> Adicionar Holerite
          </button>
        </form>
      </div>

      {/* Simulador de Rescisão */}
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <h3 className="font-semibold mb-4">Simulador de Rescisão</h3>
        <form onSubmit={handleSimulation} className="space-y-4">
          <input
            type="number"
            step="0.01"
            placeholder="Salário Base"
            value={simulationData.baseSalary}
            onChange={(e) => setSimulationData({ ...simulationData, baseSalary: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg"
          />
          <input
            type="number"
            placeholder="Meses Trabalhados"
            value={simulationData.monthsWorked}
            onChange={(e) => setSimulationData({ ...simulationData, monthsWorked: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg"
          />
          <button
            type="submit"
            className="w-full bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"
          >
            Simular
          </button>
        </form>
      </div>

      {/* CREA */}
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <h3 className="font-semibold mb-4">Anuidade CREA</h3>
        <div className="flex gap-2">
          <input
            type="number"
            step="0.01"
            placeholder="Valor da anuidade"
            value={creaFeeInput}
            onChange={(e) => setCreaFeeInput(e.target.value)}
            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg"
          />
          <button
            onClick={handleCREAFee}
            className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition"
          >
            Salvar
          </button>
        </div>
      </div>

      {/* Lista de Holerites */}
      {payrolls.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h3 className="font-semibold">Histórico de Holerites</h3>
          </div>
          <div className="divide-y divide-gray-200">
            {payrolls
              .sort((a, b) => b.month.localeCompare(a.month))
              .map((payroll) => (
                <div key={payroll.id} className="p-4 hover:bg-gray-50">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="font-semibold">{payroll.month}</p>
                      <p className="text-sm text-gray-600">{payroll.company}</p>
                    </div>
                    <button
                      onClick={() => removePayroll(payroll.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                    <div>
                      <p className="text-gray-600">Bruto</p>
                      <p className="font-medium">{formatCurrency(payroll.grossSalary)}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">INSS</p>
                      <p className="font-medium">{formatCurrency(payroll.inss)}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">IRRF</p>
                      <p className="font-medium">{formatCurrency(payroll.irrf)}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Líquido</p>
                      <p className="font-bold text-green-600">{formatCurrency(payroll.netSalary)}</p>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  )
}

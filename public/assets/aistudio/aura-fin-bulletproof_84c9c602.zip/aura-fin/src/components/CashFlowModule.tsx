import React, { useState } from 'react'
import { useFinanceStore } from '@/store/finance'
import { formatCurrency, getCategoryLabel, getCategoryColor, getMonthRange } from '@/lib/utils'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { Plus, Trash2, Calendar } from 'lucide-react'

export const CashFlowModule: React.FC = () => {
  const { transactions, addTransaction, removeTransaction, getTotalIncome, getTotalExpense } = useFinanceStore()

  const [formData, setFormData] = useState({
    type: 'expense' as const,
    amount: '',
    category: 'food' as const,
    description: '',
    date: new Date().toISOString().split('T')[0],
  })

  const today = new Date()
  const { start, end } = getMonthRange(today)

  const monthTransactions = transactions.filter(
    (t) => t.date >= start && t.date <= end
  )

  const income = getTotalIncome(start, end)
  const expense = getTotalExpense(start, end)
  const balance = income - expense

  const categoryTotals = (type: 'income' | 'expense') => {
    const grouped: Record<string, number> = {}
    monthTransactions
      .filter((t) => t.type === type)
      .forEach((t) => {
        grouped[t.category] = (grouped[t.category] || 0) + t.amount
      })
    return Object.entries(grouped).map(([category, total]) => ({
      name: getCategoryLabel(category),
      value: total,
      fill: getCategoryColor(category),
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.amount || !formData.description) return

    addTransaction({
      type: formData.type,
      amount: parseFloat(formData.amount),
      category: formData.category,
      description: formData.description,
      date: formData.date,
      status: 'completed',
    })

    setFormData({
      type: 'expense',
      amount: '',
      category: 'food',
      description: '',
      date: new Date().toISOString().split('T')[0],
    })
  }

  return (
    <div className="space-y-6">
      {/* Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 p-4 rounded-lg border border-green-200">
          <p className="text-sm text-gray-600">Entradas</p>
          <p className="text-2xl font-bold text-green-600">{formatCurrency(income)}</p>
        </div>
        <div className="bg-red-50 p-4 rounded-lg border border-red-200">
          <p className="text-sm text-gray-600">Saídas</p>
          <p className="text-2xl font-bold text-red-600">{formatCurrency(expense)}</p>
        </div>
        <div className={`p-4 rounded-lg border ${balance >= 0 ? 'bg-aurora-50 border-aurora-200' : 'bg-orange-50 border-orange-200'}`}>
          <p className="text-sm text-gray-600">Saldo</p>
          <p className={`text-2xl font-bold ${balance >= 0 ? 'text-aurora-600' : 'text-orange-600'}`}>
            {formatCurrency(balance)}
          </p>
        </div>
      </div>

      {/* Gráficos */}
      {monthTransactions.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {categoryTotals('expense').length > 0 && (
            <div className="bg-white p-4 rounded-lg border border-gray-200">
              <h3 className="font-semibold mb-4">Despesas por Categoria</h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={categoryTotals('expense')}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry) => `${entry.name}: ${((entry.value / expense) * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {categoryTotals('expense').map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => formatCurrency(value as number)} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}

          {categoryTotals('income').length > 0 && (
            <div className="bg-white p-4 rounded-lg border border-gray-200">
              <h3 className="font-semibold mb-4">Entradas por Categoria</h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={categoryTotals('income')}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry) => `${entry.name}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {categoryTotals('income').map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => formatCurrency(value as number)} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      )}

      {/* Formulário */}
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <h3 className="font-semibold mb-4">Novo Lançamento</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <select
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
              className="px-3 py-2 border border-gray-300 rounded-lg"
            >
              <option value="income">Entrada</option>
              <option value="expense">Saída</option>
            </select>

            <select
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
              className="px-3 py-2 border border-gray-300 rounded-lg"
            >
              {formData.type === 'income' && (
                <>
                  <option value="salary">Salário</option>
                  <option value="freelance">Freelancer</option>
                </>
              )}
              {formData.type === 'expense' && (
                <>
                  <option value="food">Alimentação</option>
                  <option value="transport">Transporte</option>
                  <option value="utilities">Contas</option>
                  <option value="health">Saúde</option>
                  <option value="education">Educação</option>
                  <option value="entertainment">Entretenimento</option>
                  <option value="other">Outro</option>
                </>
              )}
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input
              type="number"
              step="0.01"
              placeholder="Valor"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              className="px-3 py-2 border border-gray-300 rounded-lg"
            />
            <input
              type="date"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              className="px-3 py-2 border border-gray-300 rounded-lg"
            />
          </div>

          <input
            type="text"
            placeholder="Descrição"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg"
          />

          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 bg-aurora-600 text-white px-4 py-2 rounded-lg hover:bg-aurora-700 transition"
          >
            <Plus size={20} /> Adicionar
          </button>
        </form>
      </div>

      {/* Lista de Transações */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h3 className="font-semibold">Transações</h3>
        </div>
        <div className="divide-y divide-gray-200">
          {monthTransactions.length === 0 ? (
            <p className="p-6 text-center text-gray-500">Nenhuma transação neste mês</p>
          ) : (
            monthTransactions
              .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
              .map((transaction) => (
                <div key={transaction.id} className="p-4 flex justify-between items-center hover:bg-gray-50">
                  <div>
                    <p className="font-medium">{transaction.description}</p>
                    <p className="text-sm text-gray-600">{getCategoryLabel(transaction.category)}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <p className={`font-semibold ${transaction.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                      {transaction.type === 'income' ? '+' : '-'} {formatCurrency(transaction.amount)}
                    </p>
                    <button
                      onClick={() => removeTransaction(transaction.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              ))
          )}
        </div>
      </div>
    </div>
  )
}

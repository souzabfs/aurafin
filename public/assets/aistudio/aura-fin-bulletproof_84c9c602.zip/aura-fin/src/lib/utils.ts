import { format, parse } from 'date-fns'
import { ptBR } from 'date-fns/locale'

export const formatCurrency = (
  value: number,
  currency: string = 'BRL'
): string => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency,
  }).format(value)
}

export const formatDate = (date: string | Date): string => {
  const d = typeof date === 'string' ? parse(date, 'yyyy-MM-dd', new Date()) : date
  return format(d, 'dd \'de\' MMMM \'de\' yyyy', { locale: ptBR })
}

export const formatMonth = (date: string | Date): string => {
  const d = typeof date === 'string' ? parse(date, 'yyyy-MM-dd', new Date()) : date
  return format(d, 'MMMM/yyyy', { locale: ptBR })
}

export const getMonthRange = (date: Date): { start: string; end: string } => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const start = `${year}-${String(month).padStart(2, '0')}-01`
  const lastDay = new Date(year, month, 0).getDate()
  const end = `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`
  return { start, end }
}

export const getCategoryLabel = (category: string): string => {
  const labels: Record<string, string> = {
    salary: 'Salário',
    freelance: 'Freelancer',
    food: 'Alimentação',
    transport: 'Transporte',
    utilities: 'Contas',
    health: 'Saúde',
    education: 'Educação',
    entertainment: 'Entretenimento',
    other: 'Outro',
  }
  return labels[category] || category
}

export const getCategoryColor = (category: string): string => {
  const colors: Record<string, string> = {
    salary: '#10b981',
    freelance: '#06b6d4',
    food: '#f59e0b',
    transport: '#8b5cf6',
    utilities: '#ef4444',
    health: '#ec4899',
    education: '#6366f1',
    entertainment: '#14b8a6',
    other: '#6b7280',
  }
  return colors[category] || '#6b7280'
}

export const calculateAge = (birthDate: string | Date): number => {
  const today = new Date()
  const birth = typeof birthDate === 'string' ? new Date(birthDate) : birthDate
  let age = today.getFullYear() - birth.getFullYear()
  const monthDiff = today.getMonth() - birth.getMonth()
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--
  }
  return age
}

export const calculateMonthsDifference = (startDate: Date, endDate: Date): number => {
  return (
    endDate.getFullYear() * 12 +
    endDate.getMonth() -
    (startDate.getFullYear() * 12 + startDate.getMonth())
  )
}

export const debounce = <T extends (...args: any[]) => any>(
  func: T,
  wait: number
): ((...args: Parameters<T>) => void) => {
  let timeout: NodeJS.Timeout
  return (...args: Parameters<T>) => {
    clearTimeout(timeout)
    timeout = setTimeout(() => func(...args), wait)
  }
}

export const throttle = <T extends (...args: any[]) => any>(
  func: T,
  limit: number
): ((...args: Parameters<T>) => void) => {
  let inThrottle: boolean
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args)
      inThrottle = true
      setTimeout(() => (inThrottle = false), limit)
    }
  }
}

export const sumArray = (arr: number[]): number => arr.reduce((a, b) => a + b, 0)

export const averageArray = (arr: number[]): number =>
  arr.length > 0 ? sumArray(arr) / arr.length : 0

export const percentageChange = (initial: number, final: number): number => {
  if (initial === 0) return final === 0 ? 0 : 100
  return ((final - initial) / initial) * 100
}

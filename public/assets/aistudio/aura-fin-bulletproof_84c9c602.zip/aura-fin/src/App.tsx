import React, { useState, Suspense } from 'react'
import { CashFlowModule } from './components/CashFlowModule'
import { PayrollModule } from './components/PayrollModule'
import { IntelligenceModule } from './components/IntelligenceModule'
import { PWAInstaller } from './components/PWAInstaller'
import { Wallet, Briefcase, Brain, Settings, Home } from 'lucide-react'

type TabType = 'home' | 'cash-flow' | 'payroll' | 'intelligence' | 'settings'

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('home')

  const modules = [
    {
      id: 'cash-flow',
      label: 'Caixa',
      icon: Wallet,
      component: CashFlowModule,
    },
    {
      id: 'payroll',
      label: 'Holerite',
      icon: Briefcase,
      component: PayrollModule,
    },
    {
      id: 'intelligence',
      label: 'Inteligência',
      icon: Brain,
      component: IntelligenceModule,
    },
  ]

  return (
    <div className="max-w-screen-2xl mx-auto min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="px-4 py-4 sm:px-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-aurora-600 to-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">AF</span>
              </div>
              <h1 className="text-xl font-bold text-gray-900">AuraFin</h1>
            </div>
            <button
              onClick={() => setActiveTab('settings')}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
            >
              <Settings size={20} className="text-gray-600" />
            </button>
          </div>
        </div>

        {/* Tabs Navigation */}
        <nav className="flex overflow-x-auto border-t border-gray-200 scrollbar-hide">
          <button
            onClick={() => setActiveTab('home')}
            className={`px-4 py-3 font-medium text-sm whitespace-nowrap border-b-2 transition ${
              activeTab === 'home'
                ? 'border-aurora-600 text-aurora-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <div className="flex items-center gap-2">
              <Home size={18} />
              Início
            </div>
          </button>
          {modules.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id as TabType)}
              className={`px-4 py-3 font-medium text-sm whitespace-nowrap border-b-2 transition ${
                activeTab === id
                  ? 'border-aurora-600 text-aurora-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              <div className="flex items-center gap-2">
                <Icon size={18} />
                {label}
              </div>
            </button>
          ))}
        </nav>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8 overflow-y-auto">
        <Suspense fallback={<LoadingSpinner />}>
          {activeTab === 'home' && <HomePage />}
          {activeTab === 'cash-flow' && <CashFlowModule />}
          {activeTab === 'payroll' && <PayrollModule />}
          {activeTab === 'intelligence' && <IntelligenceModule />}
          {activeTab === 'settings' && <SettingsPage />}
        </Suspense>
      </main>

      <PWAInstaller />
    </div>
  )
}

function HomePage() {
  return (
    <div className="max-w-4xl space-y-6">
      <div className="bg-gradient-to-br from-aurora-600 to-blue-600 rounded-lg p-8 text-white shadow-lg">
        <h2 className="text-3xl font-bold mb-2">Bem-vindo ao AuraFin</h2>
        <p className="text-aurora-100">
          Sua ferramenta completa de controle financeiro pessoal, análise de holerite e inteligência financeira.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <FeatureCard
          icon={<Wallet className="text-green-600" size={32} />}
          title="Gestão de Caixa"
          description="Controle entradas, saídas e fluxo de caixa em tempo real com lembretes automáticos."
        />
        <FeatureCard
          icon={<Briefcase className="text-blue-600" size={32} />}
          title="Análise de Holerite"
          description="Simule rescisões, cálcule impostos (INSS/IRRF) e controle sua anuidade CREA."
        />
        <FeatureCard
          icon={<Brain className="text-purple-600" size={32} />}
          title="Inteligência Financeira"
          description="Receba insights personalizados e recomendações de alocação de renda."
        />
      </div>
    </div>
  )
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode
  title: string
  description: string
}) {
  return (
    <div className="bg-white p-6 rounded-lg border border-gray-200 hover:shadow-md transition">
      <div className="mb-3">{icon}</div>
      <h3 className="font-semibold mb-2">{title}</h3>
      <p className="text-sm text-gray-600">{description}</p>
    </div>
  )
}

function SettingsPage() {
  return (
    <div className="max-w-2xl space-y-6">
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <h2 className="text-xl font-bold mb-4">Configurações</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Moeda Padrão
            </label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg">
              <option>BRL - Real Brasileiro</option>
              <option>USD - Dólar Americano</option>
              <option>EUR - Euro</option>
            </select>
          </div>

          <div>
            <label className="flex items-center gap-2">
              <input type="checkbox" defaultChecked className="w-4 h-4 rounded" />
              <span className="text-sm font-medium text-gray-700">
                Notificações de Lembretes
              </span>
            </label>
          </div>

          <div>
            <label className="flex items-center gap-2">
              <input type="checkbox" defaultChecked className="w-4 h-4 rounded" />
              <span className="text-sm font-medium text-gray-700">
                Modo Escuro (tema do sistema)
              </span>
            </label>
          </div>
        </div>
      </div>

      <div className="bg-gray-50 p-4 rounded-lg text-sm text-gray-600 text-center">
        <p>AuraFin v1.0.0</p>
        <p className="text-xs mt-1">© 2024 - Todos os dados são armazenados localmente</p>
      </div>
    </div>
  )
}

function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center py-12">
      <div className="w-8 h-8 border-4 border-aurora-200 border-t-aurora-600 rounded-full animate-spin" />
    </div>
  )
}

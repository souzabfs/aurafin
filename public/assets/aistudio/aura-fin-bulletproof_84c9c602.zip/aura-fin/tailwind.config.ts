import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './src/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        aurora: {
          50: '#f0f4ff',
          100: '#e0e9ff',
          200: '#c1d3ff',
          300: '#a2bdff',
          400: '#8fa8ff',
          500: '#7893ff',
          600: '#6178ff',
          700: '#4a5cff',
          800: '#3340ff',
          900: '#1c24ff',
        },
      },
    },
  },
  plugins: [],
}

export default config

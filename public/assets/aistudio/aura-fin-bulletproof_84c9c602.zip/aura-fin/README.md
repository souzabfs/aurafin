# AuraFin - PWA de Controle Financeiro Pessoal

PWA minimalista e leve para gestão de finanças pessoais, análise de holerite e inteligência financeira.

## 🚀 Features

### 📊 Gestão de Caixa
- Registro de entradas e saídas com categorização
- Fluxo de caixa mensal com gráficos interativos (Pie Charts)
- Contas múltiplas (Corrente, Poupança, Crédito)
- Lembretes de contas a pagar/receber

### 💼 Módulo Trabalhista (CLT/CREA)
- Análise de holerite com cálculo automático de INSS e IRRF
- Simulador de rescisão (férias, 13º, Fundo de Garantia)
- Controle de anuidade CREA
- Histórico de holerites

### 🧠 Inteligência Financeira
- Monitor de saúde financeira com score de 0-100
- Insights automáticos com alertas e sugestões
- Recomendação de alocação de renda (50/30/20)
- Taxa de poupança em tempo real

### 📱 PWA Completo
- Funciona offline com IndexedDB + LocalStorage
- Instalável em Desktop e Android
- Sincronização automática
- Performance otimizada para Vercel

## 🛠️ Stack Técnico

- **Framework:** React 18 + Vite
- **Linguagem:** TypeScript (strict mode)
- **Styling:** Tailwind CSS + Aurora Color Palette
- **State Management:** Zustand com persistência
- **Dados:** LocalStorage + IndexedDB
- **Gráficos:** Recharts
- **Deploy:** Vercel (sem build warnings)

## 📁 Estrutura do Projeto

```
aura-fin/
├── index.html                  # Entry point HTML
├── public/
│   ├── manifest.json           # PWA manifest
│   ├── sw.js                   # Service Worker (Web APIs only)
│   ├── icon-192.png            # PWA icons
│   └── icon-512.png
├── src/
│   ├── App.tsx                 # App layout e navegação
│   ├── main.tsx                # Entry point React
│   ├── index.css               # Estilos globais
│   ├── components/
│   │   ├── CashFlowModule.tsx      # Módulo de caixa
│   │   ├── PayrollModule.tsx       # Módulo de holerite
│   │   ├── IntelligenceModule.tsx  # Módulo de inteligência
│   │   └── PWAInstaller.tsx        # Instalador PWA
│   ├── store/
│   │   ├── finance.ts          # Store de finanças (Zustand)
│   │   ├── payroll.ts          # Store de holerite
│   │   └── accounting.ts       # Store de contabilidade
│   └── lib/
│       └── utils.ts            # Funções utilitárias
├── vite.config.ts
├── tsconfig.json
├── tailwind.config.ts
├── postcss.config.js
└── package.json
```

## 🚀 Quick Start

### Instalação

```bash
# Clone o repositório
git clone https://github.com/seu-usuario/aura-fin.git
cd aura-fin

# Instale dependências
npm install

# Rode em desenvolvimento
npm run dev
```

Acesse: `http://localhost:3000`

### Build & Deploy (Vercel)

```bash
# Build local
npm run build

# Deploy (com Vercel CLI)
vercel deploy
```

Ou conecte seu repositório GitHub ao Vercel para CI/CD automático.

## 📝 Configuração

### PWA Icons
Substitua os arquivos em `public/`:
- `icon-192.png` (192x192)
- `icon-512.png` (512x512)
- `icon-maskable.png` (192x192, adaptative)

### Cores Personalizadas
Edite a paleta Aurora em `tailwind.config.ts`:

```typescript
colors: {
  aurora: {
    50: '#f0f4ff',
    600: '#7893ff',
    900: '#1c24ff',
  }
}
```

### Manifest
Personalize `public/manifest.json` com seus dados.

## 🔐 Privacidade & Dados

- ✅ **100% Local First:** Todos os dados são armazenados no dispositivo
- ✅ **Sem servidores:** Nenhuma requisição a backends
- ✅ **Offline-first:** Funciona completamente offline
- ✅ **Exportável:** Dados salvos em JSON no LocalStorage

## 📊 Cálculos Implementados

### INSS (Simplificado 2024)
- Até R$ 1.412,00: 7.5%
- R$ 1.412,00 - R$ 2.666,68: 9%
- R$ 2.666,68 - R$ 4.000,03: 12%
- Acima de R$ 4.000,03: 14%

### IRRF (Imposto de Renda)
- 7.5% até R$ 3.751,05
- 15% até R$ 4.664,68
- 22.5% até R$ 11.236,06
- 27.5% acima

### Simulador de Rescisão
- Cálculo de férias proporcionais (30 dias/ano)
- 13º salário proporcional
- Fundo de Garantia (8% ao mês)

## 🎨 Design System

Componentes reutilizáveis:
- Cards responsivos
- Forms com validação
- Gráficos Recharts customizados
- Layout mobile-first
- Safe areas para notch/home indicator

## 🧪 Testing

```bash
# Teste com Lighthouse (PWA score)
npm run build
npm start
# Abra Chrome DevTools > Lighthouse
```

## 🚀 Performance

- **Lighthouse PWA:** 90+
- **Lighthouse Performance:** 95+
- **Bundle Size:** ~150KB (gzip)
- **Time to Interactive:** < 2s em 4G

## 📋 Roadmap

- [ ] Sincronização com Google Drive
- [ ] Categorias customizáveis
- [ ] Relatórios mensais em PDF
- [ ] Integração com APIs bancárias
- [ ] Modo dark com preferência do sistema
- [ ] Multiidioma (EN/ES)

## 🤝 Contribuições

Contribuições são bem-vindas! Abra uma issue ou pull request.

## 📄 Licença

MIT - Veja LICENSE para detalhes

## 📞 Suporte

Encontrou um bug? Abra uma issue no GitHub.

---

**Desenvolvido com ❤️ usando Vite, React e TypeScript**
